import 'package:flutter/material.dart';
import 'package:grocery/core/classes/item.dart';
import 'package:grocery/core/services/tool.dart';
import 'package:grocery/core/viewmodels/home_model.dart';
import 'package:provider/provider.dart';
import 'package:transparent_image/transparent_image.dart';

class ItemWidget extends StatelessWidget {
  ItemWidget({Key key, @required this.item})
      : assert(item != null),
        super(key: key);

  final Item item;

  // final ItemModel itemModel;

  @override
  Widget build(BuildContext context) {
    var model = Provider.of<HomeModel>(context);
    final ThemeData theme = Theme.of(context);
    final TextStyle descriptionStyle = theme.textTheme.subhead;

    return SafeArea(
        top: false,
        bottom: false,
        child: Container(
            padding: const EdgeInsets.all(2.0),
            child: GestureDetector(
              onTap: () {},
              child: Card(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    // PHOTO
                    SizedBox(
                      height: 110.0,
                      child: Stack(
                        children: <Widget>[
                          Positioned.fill(
                            //child: Image.asset('lib/ui/images/' + item.image,
                            child: item.imageUrl == null
                                ? Image.asset('lib/ui/images/itemNotFound.jpg')
                                : FadeInImage.memoryNetwork(
                                    placeholder: kTransparentImage,
                                    fadeInDuration: const Duration(milliseconds: 100),
                                    //fadeInCurve: Curves.bounceIn,
                                    fit: BoxFit.scaleDown,
                                    image: item.imageUrl,
                                  ),
                          ),
                        ],
                      ),
                    ),
                    Divider(),
                    // NAME and PRICE
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.fromLTRB(8.0, 0.0, 8.0, 0.0),
                        child: DefaultTextStyle(
                          style: descriptionStyle,
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              // NAME
                              Padding(
                                padding: const EdgeInsets.only(bottom: 8.0),
                                child: Text(
                                  item.name,
                                  style: descriptionStyle.copyWith(
                                      color: Colors.black87, fontSize: 12),
                                ),
                              ),
                              // PRICE
                              Padding(
                                padding: const EdgeInsets.only(bottom: 8.0),
                                child: Text(
                                  item.price.toString() + '₮',
                                  style: descriptionStyle.copyWith(
                                      color: Colors.black87,
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    // ITEM DESCRIPTION
                    Padding(
                      padding: const EdgeInsets.fromLTRB(8.0, 0.0, 8.0, 0.0),
                      //child: Text(item.description1, style: descriptionStyle.copyWith(color: Colors.black54, fontSize: 10)),
                      child: Text(item.description1,
                          style: descriptionStyle.copyWith(
                              color: Colors.black54, fontSize: 10)),
                    ),
                    // BUTTONS, ACTIONS
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        // DECREASE ITEM
                        InkWell(
                          onTap: () {
                            model.decreaseOrderAmount(item);
                          },
                          child: Container(
                            alignment: Alignment.center,
                            child: Container(
                              decoration: BoxDecoration(
                                border:
                                    Border.all(color: Colors.amber.shade500),
                                borderRadius: BorderRadius.circular(30.0),
                              ),
                              width: 35.0,
                              margin: EdgeInsets.fromLTRB(10, 5, 10, 5),
                              padding: EdgeInsets.fromLTRB(10, 5, 10, 5),
                              child: Center(
                                  child: Text('-',
                                      style: TextStyle(
                                          fontSize: 14,
                                          color: Colors.amber.shade500))),
                            ),
                          ),
                        ),
                        // TOTAL ITEM
                        Container(
                          alignment: Alignment.center,
                          child: Text(
                              Tool.isNullOrZero(item.order_total)
                                  ? ''
                                  : Tool.convertDoubleToString(
                                      item.order_total),
                              style: TextStyle(color: Colors.amber.shade600)),
                        ),
                        // INCREASE ITEM
                        InkWell(
                          onTap: () {
                            model.increaseOrderAmount(item);
                          },
                          child: Container(
                            alignment: Alignment.center,
                            child: Container(
                              decoration: BoxDecoration(
                                  border:
                                      Border.all(color: Colors.amber.shade500),
                                  borderRadius: BorderRadius.circular(30.0)),
                              width: 35.0,
                              margin: EdgeInsets.fromLTRB(10, 5, 10, 5),
                              padding: EdgeInsets.fromLTRB(10, 5, 10, 5),
                              child: Center(
                                  child: Text('+',
                                      style: TextStyle(
                                          fontSize: 14,
                                          color: Colors.amber.shade500))),
                            ),
                          ),
                        ),
                      ],
                    )
                  ],
                ),
              ),
            )));
  }
}
