import 'package:flutter/material.dart';
import 'package:grocery/core/classes/navigation_bar.dart';
import 'package:grocery/core/classes/constant_classes.dart';
import 'package:grocery/core/classes/order.dart';
import 'package:grocery/core/classes/user.dart';
import 'package:grocery/core/viewmodels/home_model.dart';
import 'package:provider/provider.dart';

class TitledBottomNavigationBar extends StatefulWidget {
  const TitledBottomNavigationBar({Key key}) : super(key: key);

  @override
  _TitledBottomNavigationBarState createState() =>
      _TitledBottomNavigationBarState();
}

class _TitledBottomNavigationBarState extends State<TitledBottomNavigationBar>
    with SingleTickerProviderStateMixin {
  final List<NavigationBar> navigationBars = ConstantClasses.navigationBarList;
  static const double BAR_HEIGHT = 60;
  static const double INDICATOR_HEIGHT = 3;
  static const double INDICATOR_WIDTH = 10;
  double width = 0;
  double indicatorAlignX = -1;

  Duration duration = Duration(milliseconds: 170);

  @override
  Widget build(BuildContext context) {
    width = MediaQuery.of(context).size.width;
    return Container(
      height: BAR_HEIGHT,
      width: width,
      decoration: BoxDecoration(
          boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10)]),
      child: Stack(
        overflow: Overflow.visible,
        children: <Widget>[
          Positioned(
            top: INDICATOR_HEIGHT,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: navigationBars.map((item) {
                var index = navigationBars.indexOf(item);
                return GestureDetector(
                  onTap: () => setState(() {
                        if (ConstantClasses.navigationBarList[index].id == 'Basket') {
                          Order order = Provider.of<HomeModel>(context).getBasketList();
                          User user = Provider.of<User>(context);
                          order.user = user;
                          Navigator.pushNamed(context, '/basket', arguments: order);
                        } else {
                          Provider.of<HomeModel>(context).setSelectedTab(index);
                          Provider.of<HomeModel>(context).loadPageItemList(index);
                          indicatorAlignX = -1 + (2 / (navigationBars.length - 1) * index);
                        }
                      }),
                  child: _buildItemWidget(item, index == Provider.of<HomeModel>(context).selectedTab),
                );
              }).toList(),
            ),
          ),
          Positioned(
            top: 0,
            width: width,
            child: AnimatedAlign(
              alignment: Alignment(indicatorAlignX, 0),
              curve: Curves.linear,
              duration: duration,
              child: Container(
                color: Colors.deepOrange,
                width: width / navigationBars.length,
                height: INDICATOR_HEIGHT,
              ),
            ),
          ),
          Positioned(
            right: 16,
            top:12,
            child: Text(Provider.of<HomeModel>(context).basketItemCount.toString(),
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.deepOrange[700]),),
          )
        ],
      ),
    );
  }

  Widget _buildItemWidget(NavigationBar item, bool isSelected) {
    return Container(
      color: Colors.white,
      height: BAR_HEIGHT,
      width: width / navigationBars.length,
      child: Stack(
        alignment: AlignmentDirectional.center,
        children: <Widget>[
          AnimatedOpacity(
            opacity: isSelected ? 0.0 : 1.0,
            duration: duration,
            curve: Curves.linear,
            //child: Icon(item.icon),
            child: Image.asset('lib/ui/images/' + item.iconImage, height: 33,),
          ),
          AnimatedAlign(
            duration: duration,
            alignment: isSelected ? Alignment.center : Alignment(0, 2.6),
            child: Text(item.title),
          ),
        ],
      ),
    );
  }
}
