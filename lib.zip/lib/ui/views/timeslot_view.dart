import 'package:flutter/material.dart';
import 'package:grocery/core/classes/order.dart';
import 'package:grocery/core/enums/view_state.dart';
import 'package:grocery/core/services/tool.dart';
import 'package:grocery/core/viewmodels/timeslot_model.dart';
import 'package:grocery/ui/views/base_view.dart';

class TimeSlotView extends StatefulWidget {
  final Order order;

  TimeSlotView({@required this.order});

  @override
  _TimeSlotViewState createState() => _TimeSlotViewState();
}

class _TimeSlotViewState extends State<TimeSlotView>
    with SingleTickerProviderStateMixin {
  TabController _tabController;

  @override
  void initState() {
    _tabController = new TabController(length: 7, vsync: this);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return BaseView<TimeSlotModel>(
      onModelReady: (model) => model.getDeliveryTimeLists(widget.order),
      builder: (context, model, child) => Scaffold(
            body: model.state == ViewState.Busy
                ? Center(child: CircularProgressIndicator())
                : Container(
                    child: Column(
                    children: <Widget>[
                      // HEADER INFO
                      Expanded(
                        flex: 1,
                        child: Container(
                          decoration: new BoxDecoration(
                            image: DecorationImage(
                              image:
                              new AssetImage('lib/ui/images/header_background.png'),
                              fit: BoxFit.fitWidth,
                            ),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            mainAxisSize: MainAxisSize.max,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: <Widget>[
                              Expanded(
                                child: Container(),
                                flex: 1,
                              ),
                              Expanded(
                                child: Container(
                                  padding: EdgeInsets.only(left: 20),
                                  alignment: Alignment.centerLeft,
                                  child: Text('Нийт үнэ: ${Tool.convertDoubleToString(model.order.totalCost)} ₮',
                                    style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),),
                                ),
                                flex: 1,
                              ),
                              Expanded(
                                child: Container(
                                  padding: EdgeInsets.only(left: 20),
                                  alignment: Alignment.centerLeft,
                                  child: Text('Хүргэлтийн цаг: ${model.order.selectedDay} ${model.order.time.beginTime} - ${model.order.time.endTime}',
                                    style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),),
                                ),
                                flex: 1,
                              ),
                            ],
                          ),
                        ),
                      ),
                      // TAB VIEW - TIME INFO
                      Expanded(
                          flex: 4,
                          child: Column(
                            children: <Widget>[
                              Container(
                                height: 40,
                                child: TabBar(
                                  unselectedLabelColor: Colors.blueGrey,
                                  labelColor: Colors.deepOrange,
                                  tabs: List<Widget>.generate(model.listTimeDays.length, (int index) {
                                    return new Text(model.listTimeDays[index].stringDate);
                                  }),
                                  controller: _tabController,
                                  indicatorColor: Colors.deepOrange,
                                  indicatorSize: TabBarIndicatorSize.tab,
                                ),
                              ),
                              Flexible(
                                child: TabBarView(
                                  children: List<Widget>.generate(
                                      model.listTimeDays.length,
                                      (int indexDay) {
                                    return new ListView.builder(itemCount: model.listTimeDays[indexDay].listTime.length,
                                        itemBuilder: (BuildContext context, int indexTime) {
                                          var time = model.listTimeDays[indexDay].listTime[indexTime];
                                          return Container(color: time.isSelected ? Colors.deepOrange : Colors.white,
                                              child: ListTile(
                                                onTap: () {
                                                  model.selectDeliveryTime(
                                                      model.listTimeDays[indexDay].stringDate, time);
                                                },
                                                leading: Icon(Icons.access_time, color: (time.isSelected ? Colors.white : Colors.black)),
                                                title: Row(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  mainAxisSize: MainAxisSize.max,
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: <Widget>[
                                                    Flexible(
                                                      child: Text(time.beginTime + ' - ' + time.endTime,
                                                          style: TextStyle(fontSize: 13,
                                                              color: (time.isSelected ? Colors.white : Colors.black))),
                                                      flex: 2,
                                                    ),
                                                    Flexible(
                                                      child: Container(
                                                        padding: EdgeInsets.only(left: 10),
                                                        child: Row(
                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                            mainAxisSize: MainAxisSize.max,
                                                            crossAxisAlignment: CrossAxisAlignment.center,
                                                            children: List<Widget>.generate(indexTime % 2 + 3, (int index) {
                                                              return new Padding(padding: EdgeInsets.only(left: 10),
                                                                  child: Icon(Icons.shopping_basket));
                                                            })),
                                                      ),
                                                      flex: 5,
                                                    ),
                                                  ],
                                                ),
                                              ));
                                        });
                                  }),
                                  controller: _tabController,
                                ),
                              )
                            ],
                          )),
                    ],
                  )),
            bottomNavigationBar: Container(
              color: Colors.grey[200],
              height: 55,
              padding: EdgeInsets.fromLTRB(5, 5, 5, 5),
              child: RaisedButton(
                textColor: Colors.white,
                color: Colors.green[400],
                disabledColor: Colors.grey,
                disabledTextColor: Colors.white,
                elevation: 4.0,
                child: Text('Баталгаажуулах'),
                onPressed: () {
                  Navigator.pushNamed(context, '/home');
                },
              ),
            ),
          ),
    );
  }
}
