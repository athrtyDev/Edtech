import 'package:flutter/material.dart';
import 'package:grocery/core/classes/constant_classes.dart';
import 'package:grocery/core/classes/item.dart';
import 'package:grocery/core/enums/view_state.dart';
import 'package:grocery/core/viewmodels/home_model.dart';
import 'package:grocery/ui/views/base_view.dart';
import 'package:grocery/ui/widgets/item_widget.dart';
import 'package:provider/provider.dart';

class ItemView extends StatefulWidget {
  @override
  _ItemViewState createState() => _ItemViewState();
}

class _ItemViewState extends State<ItemView> {
  @override
  Widget build(BuildContext context) {
    var model = Provider.of<HomeModel>(context);
    var size = MediaQuery.of(context).size;
    final double itemHeight = (size.height - kToolbarHeight - 24) / 3;
    final double itemWidth = size.width / 2;

    return model.state == ViewState.Busy
        ? Center(child: CircularProgressIndicator())
        : Container(
            child: (model.currentPageItemList == null
                ? Center(
                    child: Text(
                        'Одоогоор бараа байхгүй байна. ${ConstantClasses.navigationBarList[model.selectedTab].title}'))
                : (Container(
                    child: GridView.count(
                      crossAxisCount: 2,
                      childAspectRatio: (itemWidth / itemHeight),
                      shrinkWrap: true,
                      scrollDirection: Axis.vertical,
                      padding: const EdgeInsets.all(4.0),
                      children: model.currentPageItemList.map((Item item) {
                        return ItemWidget(
                          item: item,
                        );
                      }).toList(),
                    ),
                  ))),
          );
  }
}
