import 'package:flutter/material.dart';
import 'package:grocery/core/classes/order.dart';
import 'package:grocery/core/services/tool.dart';
import 'package:grocery/core/viewmodels/basket_model.dart';
import 'package:grocery/ui/views/base_view.dart';
import 'package:transparent_image/transparent_image.dart';

class BasketView extends StatefulWidget {
  final Order order;

  BasketView({@required this.order});

  @override
  _BasketViewState createState() => _BasketViewState();
}

class _BasketViewState extends State<BasketView> {
  @override
  Widget build(BuildContext context) {
    return BaseView<BasketModel>(
      onModelReady: (model) => model.initBasket(widget.order),
      builder: (context, model, child) => Scaffold(
            body: Container(
              child: Column(
                children: <Widget>[
                  Expanded(
                    flex: 1,
                    child: Container(
                      decoration: new BoxDecoration(
                        image: DecorationImage(
                          image: new AssetImage('lib/ui/images/header_background.png'),
                          fit: BoxFit.fitWidth,
                        ),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          Expanded(
                            child: Container(),
                            flex: 1,
                          ),
                          Expanded(
                            child: Container(
                                padding: EdgeInsets.only(left: 20),
                                alignment: Alignment.centerLeft,
                                child: Text('Нийт үнэ: ${Tool.convertDoubleToString(model.order.totalCost)} ₮',
                                  style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),),
                            ),
                            flex: 1,
                          ),
                          Expanded(
                            child: Container(
                              padding: EdgeInsets.only(left: 20),
                              alignment: Alignment.centerLeft,
                              child: Text('Хэрэглэгч: ${model.order.user.password}',
                                style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),),
                            ),
                            flex: 1,
                          ),
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 4,
                    child: ListView.builder(
                        itemCount: model.order.listItem.length,
                        itemBuilder: (BuildContext context, int position) {
                          var item = model.order.listItem[position];
                          return Container(
                              decoration: BoxDecoration(
                                border: Border(bottom: BorderSide(color: Colors.grey)),
                              ),
                              child: ListTile(
                                  contentPadding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 3.0),
                                  leading: Container(
                                      width: 45.0,
                                      height: 45.0,
                                      child: Center(
                                          child: item.imageUrl == null
                                              ? Image.asset('lib/ui/images/itemNotFound.jpg')
                                              : FadeInImage.memoryNetwork(
                                            placeholder: kTransparentImage,
                                            fadeInDuration: const Duration(
                                                milliseconds: 100),
                                            fit: BoxFit.scaleDown,
                                            image: item.imageUrl,
                                          ))
                                  ),
                                  title: Text(item.name,
                                      style: TextStyle(fontSize: 13, fontWeight: FontWeight.w400)),
                                  subtitle: Container(
                                    child: Text(
                                      item.description1,
                                      style: TextStyle(fontSize: 10),
                                    ),
                                  ),
                                  trailing: Container(
                                    width: 120.0,
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      mainAxisSize: MainAxisSize.max,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: <Widget>[
                                        Expanded(
                                          child: Container(
                                            child: InkWell(
                                              onTap: () {
                                                model.decreaseOrderAmount(item);
                                              },
                                              child: Container(
                                                alignment: Alignment.center,
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    border: Border.all(color: Colors.amber.shade500),
                                                    borderRadius:
                                                    BorderRadius.circular(25.0),
                                                  ),
                                                  width: 30.0,
                                                  margin: EdgeInsets.fromLTRB(5, 5, 5, 5),
                                                  padding: EdgeInsets.fromLTRB(5, 5, 5, 5),
                                                  child: Center(
                                                      child: Text('-',
                                                          style: TextStyle(
                                                              fontSize: 14,
                                                              color: Colors.amber.shade500))),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Expanded(
                                          child: Container(
                                            height: 30,
                                            decoration: BoxDecoration(
                                                border: Border.all(
                                                    width: 1,
                                                    color: Colors.amber.shade500)),
                                            child: Center(
                                                child: Text(
                                                    Tool.convertDoubleToString(
                                                        item.order_total))),
                                          ),
                                        ),
                                        Expanded(
                                          child: Container(
                                              child: InkWell(
                                                onTap: () {
                                                  model.increaseOrderAmount(item);
                                                },
                                                child: Container(
                                                  alignment: Alignment.center,
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                      border: Border.all(
                                                          color: Colors.amber.shade500),
                                                      borderRadius:
                                                      BorderRadius.circular(25.0),
                                                    ),
                                                    width: 30.0,
                                                    margin:
                                                    EdgeInsets.fromLTRB(5, 5, 5, 5),
                                                    padding:
                                                    EdgeInsets.fromLTRB(5, 5, 5, 5),
                                                    child: Center(
                                                        child: Text('+',
                                                            style: TextStyle(
                                                                fontSize: 14,
                                                                color: Colors
                                                                    .amber.shade500))),
                                                  ),
                                                ),
                                              )),
                                        ),
                                      ],
                                    ),
                                  )));
                        }),
                  ),
                ],
              )
            ),
            bottomNavigationBar: Container(
              color: Colors.grey[200],
              height: 55,
              padding: EdgeInsets.fromLTRB(5, 5, 5, 5),
              child: RaisedButton(
                textColor: Colors.white,
                color: Colors.green[400],
                disabledColor: Colors.grey,
                disabledTextColor: Colors.white,
                elevation: 4.0,
                child: Text('Захиалга өгөх'),
                onPressed: () {
                  Navigator.pushNamed(context, '/timeslot', arguments: model.order);
                },
              ),
            ),
          ),
    );
  }
}
