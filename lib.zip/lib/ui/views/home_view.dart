import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:grocery/core/classes/layout_type.dart';
import 'package:grocery/core/viewmodels/home_model.dart';
import 'package:grocery/ui/views/base_view.dart';
import 'package:grocery/ui/views/item_view.dart';
import 'package:grocery/ui/widgets/bottom_navigation.dart';
import 'package:flutter/foundation.dart';

class HomeView extends StatefulWidget {
  HomeView({Key key}) : super(key: key);

  @override
  _HomeViewState createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView>
    with SingleTickerProviderStateMixin
    implements HasLayoutGroup {
  _HomeViewState({Key key, this.layoutGroup, this.onLayoutToggle});

  final LayoutGroup layoutGroup;
  final VoidCallback onLayoutToggle;
  TextEditingController _searchInput;
  ScrollController _scrollViewController;

  @override
  void initState() {
    super.initState();
    _scrollViewController = ScrollController();
    _searchInput = TextEditingController();
  }

  @override
  void dispose() {
    super.dispose();
    _scrollViewController.dispose();
    _searchInput.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BaseView<HomeModel>(
        onModelReady: (model) => model.loadAllItemList(),
        builder: (context, model, child) => Scaffold(
              body: SafeArea(
                child: NestedScrollView(
                  controller: _scrollViewController,
                  headerSliverBuilder: (BuildContext context, bool boxIsScrolled) {
                    return <Widget>[
                      SliverPersistentHeader(
                        pinned: true,
                        floating: false,
                        delegate: HeroHeader(
                          layoutGroup: layoutGroup,
                          onLayoutToggle: onLayoutToggle,
                          minExtent: 50.0,
                          maxExtent: 200.0,
                        ),
                      ),
                    ];
                  },
                  body: ItemView(),
                ),
              ),
              bottomNavigationBar: TitledBottomNavigationBar(),
            ));
  }
}

/*new Container(
                child: Stack(fit: StackFit.expand, children: <Widget>[
                  Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[

                        Text('Welcome ${Provider.of<User>(context).password}'),
                        Text(model.selectedTab.toString()),
                      ])
                ]),
              ),*/

class HeroHeader implements SliverPersistentHeaderDelegate {
  HeroHeader({
    this.layoutGroup,
    this.onLayoutToggle,
    this.minExtent,
    this.maxExtent,
  });

  final LayoutGroup layoutGroup;
  final VoidCallback onLayoutToggle;
  double maxExtent;
  double minExtent;
  final TextEditingController _searchInput = TextEditingController();

  @override
  Widget build(
      BuildContext context, double shrinkOffset, bool overlapsContent) {
    return Container(
      decoration: new BoxDecoration(
        image: DecorationImage(
          image:
          new AssetImage('lib/ui/images/header_background.png'),
          fit: BoxFit.fitWidth,
        ),
      ),
      child: Stack(
        fit: StackFit.passthrough,
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(0.0),
                  height: 150.0,
                ),
              ),
              Container(
                margin: const EdgeInsets.only(left: 6.0, right: 6.0, bottom: 5.0, top: 5.0),
                constraints: BoxConstraints.expand(height: 40),
                color: Colors.white,
                alignment: Alignment.center,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    SizedBox(width: 5.0),
                    Flexible(
                      fit: FlexFit.tight,
                      child: new SizedBox(
                        height: 45.0,
                        child: Card(
                          child: TextField(
                            controller: _searchInput,
                            keyboardType: TextInputType.text,
                            decoration: InputDecoration(
                              hintText: ' Хайх...',
                              hintStyle: TextStyle(
                                  color: Colors.grey,
                                  fontSize: 17.0,
                                  fontFamily: 'Poppins'),
                              border: InputBorder.none,
                            ),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  bool shouldRebuild(SliverPersistentHeaderDelegate oldDelegate) {
    return true;
  }

  @override
  FloatingHeaderSnapConfiguration get snapConfiguration => null;
}
