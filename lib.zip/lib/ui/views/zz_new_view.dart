/*
import 'package:flutter/material.dart';
import 'package:grocery/ui/views/base_view.dart';
import '../../core/viewmodels/home_model.dart';

class HomeView extends StatefulWidget {
  @override
  _HomeViewState createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  @override
  Widget build(BuildContext context) {
    return BaseView<HomeModel>(
      builder: (context, model, child) => Scaffold(
          body: Column(
            children: <Widget>[
              Text('Hello'),
            ],
          )
      ),
    );
  }
}*/
