import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:grocery/core/classes/item.dart';
import 'package:grocery/core/classes/order.dart';
import 'package:grocery/ui/views/basket_view.dart';
import 'package:grocery/ui/views/home_view.dart';
import 'package:grocery/ui/views/login_view.dart';
import 'package:grocery/ui/views/timeslot_view.dart';

class Router {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch(settings.name) {
      case '/login':
        return MaterialPageRoute(builder: (_) => LoginView());
      case '/home':
        return MaterialPageRoute(builder: (_) => HomeView());
      case '/basket':
        var order = settings.arguments as Order;
        return MaterialPageRoute(builder: (_) => BasketView(order: order));
      case '/timeslot':
        var order = settings.arguments as Order;
        return MaterialPageRoute(builder: (_) => TimeSlotView(order: order));
      default:
        return MaterialPageRoute(builder: (_) => Scaffold(
          body: Center(child: Text('No route defined for ${settings.name}')),
        ));
    }
  }
}