import 'package:get_it/get_it.dart';
import 'package:grocery/core/services/api.dart';
import 'package:grocery/core/services/authentication_service.dart';
import 'package:grocery/core/viewmodels/basket_model.dart';
import 'package:grocery/core/viewmodels/home_model.dart';
import 'package:grocery/core/viewmodels/item_model.dart';
import 'package:grocery/core/viewmodels/login_model.dart';
import 'package:grocery/core/viewmodels/timeslot_model.dart';

GetIt locator = GetIt();

void setupLocator() {
  locator.registerLazySingleton(() => AuthenticationService());
  locator.registerLazySingleton(() => Api());
  locator.registerLazySingleton(() => LoginModel());
  locator.registerFactory(() => HomeModel());
  locator.registerFactory(() => ItemModel());
  locator.registerFactory(() => BasketModel());
  locator.registerFactory(() => TimeSlotModel());
}