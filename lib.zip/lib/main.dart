import 'package:flutter/material.dart';
import 'package:grocery/core/classes/user.dart';
import 'package:grocery/core/services/authentication_service.dart';
import 'package:grocery/locator.dart';
import 'package:grocery/ui/router.dart';
import 'package:provider/provider.dart';

void main() {
  setupLocator();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return StreamProvider<User>(
      initialData: User.initial(),
      builder: (context) => locator<AuthenticationService>().userController,
      child: MaterialApp(
        title: 'Grocery',
        theme: ThemeData(),
        initialRoute: '/home',
        onGenerateRoute: Router.generateRoute,
      ),
    );
  }
}
