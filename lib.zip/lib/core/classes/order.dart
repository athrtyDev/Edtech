import 'package:grocery/core/classes/delivery_time.dart';
import 'package:grocery/core/classes/item.dart';
import 'package:grocery/core/classes/user.dart';

class Order {
  User user;
  List<Item> listItem;
  DeliveryTime time;
  String selectedDay;
  double totalCost;

  Order ({this.user, this.listItem, this.selectedDay, this.time, this.totalCost});
}