import 'package:grocery/core/classes/navigation_bar.dart';
import 'package:grocery/ui/views/basket_view.dart';
import 'package:grocery/ui/views/item_view.dart';

class ConstantClasses {
  static final List<NavigationBar> navigationBarList = [
    NavigationBar('General', 'Хүнс', 'icon_general.png', ItemView()),
    NavigationBar('Vegetable', 'Ногоо', 'icon_vegetable.png', ItemView()),
    NavigationBar('Fruit', 'Жимс', 'icon_fruit.png', ItemView()),
    NavigationBar('Drink', 'Ундаа', 'icon_drink.png', ItemView()),
    NavigationBar('Basket', 'Сагс', 'icon_basket.jpg', BasketView()),
  ];

  static final int futureOrderDays = 3;
  static final int stopDeliveryPriorMin = 30;
}