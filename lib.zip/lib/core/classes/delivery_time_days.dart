import 'package:grocery/core/classes/delivery_time.dart';

class DeliveryTimeDays {
  String stringDate;
  List<DeliveryTime> listTime;

  DeliveryTimeDays({this.stringDate, this.listTime});
}