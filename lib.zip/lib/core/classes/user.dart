class User {
  String phone;
  String password;
  String area;
  User({this.phone, this.password, this.area});

  User.initial()
      : phone = '',
        password = '',
        area = '';

  User.fromJson(Map<String, dynamic> json) {
    phone = json['phone'];
    password = json['password'];
    area = json['area'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['phone'] = this.phone;
    data['password'] = this.password;
    data['area'] = this.area;
    return data;
  }
}
