import 'package:grocery/core/enums/view_state.dart';
import 'package:grocery/core/services/authentication_service.dart';
import 'package:grocery/core/viewmodels/base_model.dart';
import 'package:grocery/locator.dart';

class LoginModel extends BaseModel {
  final AuthenticationService _authenticationService = locator<AuthenticationService>();

  var customer;
  String errorMessage;

  Future<bool> login(String phone) async {
    setState(ViewState.Busy);

    bool success = await _authenticationService.readCustomer(phone);
    if(success)
      errorMessage = null;
    else
      errorMessage = 'Утасны дугаар буруу байна.';
    setState(ViewState.Idle);
    return success;
  }
}