import 'dart:collection';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:grocery/core/classes/constant_classes.dart';
import 'package:grocery/core/classes/item.dart';
import 'package:grocery/core/classes/order.dart';
import 'package:grocery/core/classes/delivery_time.dart';
import 'package:grocery/core/enums/view_state.dart';
import 'package:grocery/core/services/api.dart';
import 'package:grocery/core/viewmodels/base_model.dart';
import 'package:grocery/locator.dart';

class HomeModel extends BaseModel {
  int _selectedTab;
  final Api _api = locator<Api>();
  List<Item> allItemList;
  List<Item> currentPageItemList;
  HashMap mapItemByPage;
  int basketItemCount;

  void loadAllItemList() async {
    setState(ViewState.Busy);
    // Get all list
    _selectedTab = 0;
    basketItemCount = 0;
    allItemList = await _api.getAllItemList();

    // Group items by id's
    mapItemByPage = new HashMap<String, List<Item>>();
    for(var item in allItemList) {
      List<Item> tempList;
      if(mapItemByPage.containsKey(item.type))
        tempList = mapItemByPage[item.type];
      else
        tempList = new List<Item>();

      tempList.add(item);
      mapItemByPage[item.type] = tempList;
    }
    loadPageItemList(_selectedTab);
    setState(ViewState.Idle);
    print('************************************* Load all items. Count: ' + (allItemList == null ? 0 : allItemList.length.toString()));
  }

  void loadPageItemList(int selectedTab) async {
    // Get selected page's item list
    String tabId = ConstantClasses.navigationBarList[selectedTab].id;
    if(mapItemByPage.containsKey(tabId))
      currentPageItemList = mapItemByPage[tabId];
    else
      currentPageItemList = null;
    loadImages();
    notifyListeners();
    print('************************************* Current page list update.');
  }

  Order getBasketList() {
    // Collect ordered item's from itemList of HashMap
    List<Item> basketList = new List<Item>();
    mapItemByPage.forEach((key, value) {
      List<Item> listItem = value;
      if(listItem != null) {
        for(var item in listItem) {
          if(item.order_count != null && item.order_count > 0)
            basketList.add(item);
        }
      }
    });
    print('************************************* Go to Basket. List count: ' + (basketList == null ? 0 : basketList.length.toString()));
    Order order = new Order(listItem: basketList, time: new DeliveryTime());
    return order;
  }

  void loadImages() async {
    if(currentPageItemList != null) {
      for(var item in currentPageItemList) {
        if(item.image != null) {
          StorageReference reference = FirebaseStorage.instance.ref().child(item.image);
          item.imageUrl = await reference.getDownloadURL();
        }
      }
    }
    notifyListeners();
  }

  void increaseOrderAmount(Item selectedItem) {
    if(selectedItem.order_count == null) selectedItem.order_count = 0;
    if(selectedItem.order_total == null) selectedItem.order_total = 0;
    // TEMP = remove after
    if(selectedItem.measure_amount == null) selectedItem.measure_amount = 2;

    // basket info calculation
    if(selectedItem.order_count == 0) basketItemCount++;

    // item info calculation
    selectedItem.order_count++;
    selectedItem.order_total = selectedItem.order_count * selectedItem.measure_amount;
    notifyListeners();
  }

  void decreaseOrderAmount(Item selectedItem) {
    if(selectedItem.order_count == null) selectedItem.order_count = 0;
    if(selectedItem.order_total == null) selectedItem.order_total = 0;
    // TEMP = remove after
    if(selectedItem.measure_amount == null) selectedItem.measure_amount = 2;

    // item info calculation
    if(selectedItem.order_count != 0) {
      selectedItem.order_count--;
      selectedItem.order_total = selectedItem.order_count * selectedItem.measure_amount;
      // basket info calculation
      if(selectedItem.order_count == 0) basketItemCount--;
    }

    notifyListeners();
  }

  // Getter and Setter
  int get selectedTab {
    if(_selectedTab == null)
      _selectedTab = 0;
    return _selectedTab;
  }

  void setSelectedTab(int selectedTab) {
    _selectedTab = selectedTab;
    notifyListeners();
  }
}