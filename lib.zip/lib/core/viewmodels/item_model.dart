import 'package:grocery/core/viewmodels/base_model.dart';

class ItemModel extends BaseModel {

}