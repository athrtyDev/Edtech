import 'dart:collection';
import 'package:grocery/core/classes/constant_classes.dart';
import 'package:grocery/core/classes/delivery_time.dart';
import 'package:grocery/core/classes/delivery_time_days.dart';
import 'package:grocery/core/classes/order.dart';
import 'package:grocery/core/enums/view_state.dart';
import 'package:grocery/core/services/api.dart';
import 'package:grocery/core/viewmodels/base_model.dart';
import 'package:grocery/locator.dart';
import 'package:intl/intl.dart';

class TimeSlotModel extends BaseModel {
  final Api _api = locator<Api>();
  Order order;
  List<DeliveryTimeDays> listTimeDays;
  DeliveryTime oldSelectedTime;
  String confirmOrderErrorMessage;

  // Select delivery time page ruu newtreh uyd:
  // unuudruus ireh 3n udur hurtleh tsagiin jagsaaltiig awchrah
  void getDeliveryTimeLists(Order order) async {
    setState(ViewState.Busy);
    this.order = order;
    int futureDays = ConstantClasses.futureOrderDays;

    // Get all time and group custom days
    List<DeliveryTime> listAllTime = await _api.getDeliveryTime();
    HashMap mapTimeByDay = new HashMap<String, List<DeliveryTime>>();
    for (var time in listAllTime) {
      // Group them by either 'Regular' or custom day
      String key = (time.type == 'Regular' ? 'Regular' : time.customDay);
      List<DeliveryTime> customList;

      if (mapTimeByDay.containsKey(key))
        customList = mapTimeByDay[key];
      else
        customList = new List<DeliveryTime>();

      // add list to hashmap with day key
      customList.add(time);
      customList.sort((a, b) => a.beginTime.compareTo(b.beginTime));
      mapTimeByDay[key] = customList;
    }

    // Set today's time STATUS if it is in the past
    if (mapTimeByDay.containsKey('Regular')) {
      List<DeliveryTime> listTodayTime = mapTimeByDay['Regular'];

      DateFormat dateFormatWithHour = DateFormat("yyyy-MM-dd HH:mm:ss");
      DateFormat dateFormat = DateFormat("yyyy-MM-dd");
      String stringToday = dateFormat.format(DateTime.now());
      DateTime now = DateTime.now();
      now = now.add(Duration(minutes: ConstantClasses.stopDeliveryPriorMin));

      for (var time in listTodayTime) {
        DateTime endTime = dateFormatWithHour.parse(stringToday + " " + time.endTime + ':00');
        if (now.isAfter(endTime)) time.isPastTime = true;
        print('bbbbbbbbbbbbbbbbb: ' + time.beginTime + ' ' + time.isPastTime.toString() + ' ${now.toString()}');
      }
    }

    // Prepare next X day's time list
    listTimeDays = new List<DeliveryTimeDays>();
    for (var i = 0; i < futureDays; i++) {
      // loop day
      var orderDay = DateTime.now();
      orderDay = orderDay.add(Duration(days: i));
      // Get that day's time setting
      List<DeliveryTime> listCurrentDayTime;
      String stringDay = DateFormat('yyyy-MM-dd').format(orderDay);
      // check if that loop day has custom orderday setting
      if (mapTimeByDay.containsKey(stringDay)) // means there is custom settings on that day
        listCurrentDayTime = mapTimeByDay[stringDay];
      else if (mapTimeByDay.containsKey('Regular')) { // no custom, so get Regular setting
        List<DeliveryTime> listTemp = new List<DeliveryTime>();
        for(var time in mapTimeByDay['Regular'])
          listTemp.add(DeliveryTime(type: time.type, customDay: time.customDay, beginTime: time.beginTime,
              endTime: time.endTime, isPastTime: time.isPastTime, isSelected: time.isSelected));
        listCurrentDayTime = listTemp;
      }

      DeliveryTimeDays timeDay = DeliveryTimeDays(stringDate: stringDay, listTime: listCurrentDayTime);
      print('cccccccc: ' + stringDay + ' ' + listCurrentDayTime.length.toString());
      listTimeDays.add(timeDay);
    }
    setState(ViewState.Idle);
  }

  void selectDeliveryTime(String stringDay, DeliveryTime time) {
    if(oldSelectedTime != null)
      oldSelectedTime.isSelected = false;
    time.isSelected = true;
    oldSelectedTime = time;
    order.time = time;
    order.selectedDay = stringDay;
    notifyListeners();
  }

  void confirmOrder() {
    setState(ViewState.Busy);
    confirmOrderErrorMessage = checkOrder();
    if(confirmOrderErrorMessage == null) {  // no error

    }


    setState(ViewState.Idle);
  }

  String checkOrder() {
    String error;
    if(order.listItem == null || order.listItem.length == 0)
      error = 'Та худалдан авах бараа сонгоогүй байна!';
    //else if(order.selectedDay)

    return error;
  }
}
