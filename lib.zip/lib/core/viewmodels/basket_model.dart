import 'package:grocery/core/classes/item.dart';
import 'package:grocery/core/classes/order.dart';
import 'package:grocery/core/viewmodels/base_model.dart';

class BasketModel extends BaseModel {
  Order order;

  void initBasket(Order order) {
    this.order = order;
    calculateTotalItemCost();
    notifyListeners();
  }

  void calculateTotalItemCost() {
    double totalCost = 0;
    for(var item in order.listItem)
      totalCost += item.order_total * item.price;
    order.totalCost = totalCost;
  }

  void increaseOrderAmount(Item selectedItem) {
    if(selectedItem.order_count == null) selectedItem.order_count = 0;
    if(selectedItem.order_total == null) selectedItem.order_total = 0;
    // TEMP = remove after
    if(selectedItem.measure_amount == null) selectedItem.measure_amount = 2;

    selectedItem.order_count++;
    selectedItem.order_total = selectedItem.order_count * selectedItem.measure_amount;
    calculateTotalItemCost();
    notifyListeners();
  }

  void decreaseOrderAmount(Item selectedItem) {
    if(selectedItem.order_count == null) selectedItem.order_count = 0;
    if(selectedItem.order_total == null) selectedItem.order_total = 0;
    // TEMP = remove after
    if(selectedItem.measure_amount == null) selectedItem.measure_amount = 2;

    if(selectedItem.order_count != 0) {
      selectedItem.order_count--;
      selectedItem.order_total = selectedItem.order_count * selectedItem.measure_amount;
      calculateTotalItemCost();
      notifyListeners();
    }
  }
}