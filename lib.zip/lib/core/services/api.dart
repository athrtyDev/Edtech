import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:grocery/core/classes/delivery_time.dart';
import 'package:grocery/core/classes/item.dart';
import 'package:http/http.dart' as http;
import 'package:grocery/core/classes/user.dart';

class Api {
  static const endpoint = 'https://jsonplaceholder.typicode.com';

  var client = new http.Client();

  Future<User> getUserProfile(int userId) async {
    // Get user profile for id
    var response = await client.get('$endpoint/users/$userId');

    // Convert and return
    return User.fromJson(json.decode(response.body));
  }

  Future<List<Item>> getAllItemList() async {
    QuerySnapshot itemSnapshot = await Firestore.instance
        .collection('Items')
        .getDocuments();

    if(itemSnapshot.documents.isEmpty)
      return null;
    else
      return itemSnapshot.documents.map((item) => new Item.fromJson(item.data)).toList();
  }

  Future<List<DeliveryTime>> getDeliveryTime() async {
    QuerySnapshot itemSnapshot = await Firestore.instance
        .collection('DeliveryTime')
        .getDocuments();

    if(itemSnapshot.documents.isEmpty)
      return null;
    else
      return itemSnapshot.documents.map((item) => new DeliveryTime.fromJson(item.data)).toList();
  }
}
