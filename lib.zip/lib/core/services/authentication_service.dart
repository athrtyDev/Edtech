import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:grocery/core/classes/user.dart';

class AuthenticationService {
  StreamController<User> userController = StreamController<User>();

  Future<bool> readCustomer(String phone) async {
    QuerySnapshot customerSnapshot = await Firestore.instance
        .collection('Customer')
        .where('phone', isEqualTo: phone)
        .getDocuments();

    if(customerSnapshot.documents.isEmpty) {
      return false;
    }
    else {
      userController.add(User.fromJson(customerSnapshot.documents[0].data));
      return true;
    }
  }
}
